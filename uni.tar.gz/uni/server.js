var fs = require('fs');

var data = fs.readFileSync('data.json');

var express = require('express');
var path = require("path");
var app = express();

app.use(express.static(path.join(__dirname, 'img')));

app.get('/',function(req,res){
	  res.sendFile(path.join(__dirname+'/home.html'));
	  //__dirname : It will resolve to your project folder.
	});

	app.get('/one',function(req,res){
	  res.sendFile(path.join(__dirname+'/one.html'));
	});

	app.get('/two',function(req,res){
	  res.sendFile(path.join(__dirname+'/two.html'));
	});
	
	app.get('/three',function(req,res){
		  res.sendFile(path.join(__dirname+'/three.html'));
	});
	
	app.get('/previousCourses',function(req,res){
		  res.sendFile(path.join(__dirname+'/previousCourses.html'));
	});
	
	app.get('/student',function(req,res){
		  res.sendFile(path.join(__dirname+'/student.html'));
	});
	
	app.get('/campus',function(req,res){
		  res.sendFile(path.join(__dirname+'/campus.html'));
	});
	
	app.get('/geo',function(req,res){
		  res.sendFile(path.join(__dirname+'/geo.html'));
	});
	
	
app.listen(3338, function () {
    console.log('Server is up! Port 3338');
});